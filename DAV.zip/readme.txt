Use colab to run the code,if you use PyCharm or something else,please make sure everything is in the same file

Install required packages using:
pip install -r requirements1.txt,this only include basic libraries
if it cannot work,use requirements2.txt,this is what I used to run on PyCharm

If they all fail
View the pre-generated visualisations
Simply double-click the following files:

global_fertility_trend.html
fertility_rate_world_map_animated.html
Or the.png file with same names as above
No Python installation is required to view the outputs.

fertility_rate_cleaned_20260430_0505.csv is the data file
Data Source
Source: Our World in Data
Original Dataset: Children per woman (Total Fertility Rate)
Link: https://ourworldindata.org/fertility-rate
Underlying Source: United Nations, World Population Prospects

Contact
Student ID: [c25003882]